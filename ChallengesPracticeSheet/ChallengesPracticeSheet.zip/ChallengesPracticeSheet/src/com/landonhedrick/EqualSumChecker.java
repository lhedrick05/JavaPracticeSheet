package com.landonhedrick;

public class EqualSumChecker {

    public static boolean hasEqualSum(int x, int y, int z) {
        if(x + y == z) {
            return true;
        } else {
            return false;
        }
    }
}
